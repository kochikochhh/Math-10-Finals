# Math 10 Reviewers

Study sites for UP MATH 10 (Mathematics, Culture and Society), Modules 2 to 9. Each module has a reviewer, a shuffled quiz with explanations, and interactive tools.

Open `index.html` for the list of all modules.

| Module | Page | Tools |
|---|---|---|
| 2 Logic and Reasoning | `module-2-logic.html` | 2.1 Truth table builder |
| 3 Axiomatic Systems | `module-3-axiomatic-systems.html` | |
| 4 Sets | `module-4-sets.html` | 4.1 Set calculator, 4.2 Survey solver |
| 5 Numbers and Patterns | `module-5-numbers-and-patterns.html` | 5.1 Caesar Cipher Lab (`module-5-caesar-cipher-lab.html`), 5.2 How to convert bases, 5.3 Number converter, 5.4 Cipher tool y = ax + b, 5.5 Zₙ tables |
| 6 Shapes | `module-6-geometries.html` | |
| 7 | not added yet | |
| 8 Arts and Humanities | `module-8-arts-and-humanities.html` | 8.1 Weaving methods, 8.2 Weave grid |
| 9 Social Sciences | `module-9-social-sciences.html` | 9.1 Election calculator, 9.2 Banzhaf calculator, 9.3 Apportionment calculator |

Each page is a single self-contained HTML file. Fonts load from Google Fonts, and the pages work offline with fallback fonts.

To publish as a website: in the repository, go to **Settings → Pages**, set the source to the `main` branch and the root folder, then save. The site will appear at `https://<your-username>.github.io/<repo-name>/`.
